function isAuthenticated(req, res, next) {
    // Check if the user is logged in by checking the presence of a specific cookie
    if (req.cookies.userLogin === 'true') {
      // User is authenticated, proceed to the next middleware or route handler
      next();
    } else {
      // User is not authenticated, redirect to the login page or another route
      res.redirect('/?error=Not authenticated');
    }
  }
  
  module.exports = isAuthenticated;
  