const express = require('express');
const cookieParser = require('cookie-parser');
const router = express.Router();
const connection = require('../database');

// Route for rendering the login form
router.get('/', (req, res) => {
  res.render('login');
});

// Route for handling login form submission (POST request)
router.post('/', (req, res) => {
  
  const { email, password } = req.body;

  // Validate form data (you can add more validation as needed)

  // Check if user exists in the database
  const query = 'SELECT id, username, email FROM users WHERE email = ? AND password = ?';
  connection.query(query, [email, password], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    if (results.length > 0) {
      // Authentication successful
      const user = results[0];
      
      // Set userLogin flag in cookies
      res.cookie('userLogin', true);
      
      // Save user information in cookies
      res.cookie('userId', user.id);
      res.cookie('username', user.username);
      res.cookie('userEmail', user.email);

      // Redirect to dashboard or perform any other action
      res.redirect('/home');
    } else {
      // Authentication failed
      // Redirect to login page with an error message
      res.redirect('/?error=1');
    }
  });
});

module.exports = router;
